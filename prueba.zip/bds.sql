-- Volcando estructura para tabla prueba.administradores
CREATE TABLE IF NOT EXISTS `administradores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `foto_perfil` text DEFAULT NULL,
  `creado_por` varchar(100) DEFAULT NULL,
  `actualizado_por` varchar(100) DEFAULT NULL,
  `creado_en` timestamp NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `usuario` (`usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla prueba.administradores: ~1 rows (aproximadamente)
INSERT INTO `administradores` (`id`, `usuario`, `password_hash`, `nombre`, `foto_perfil`, `creado_por`, `actualizado_por`, `creado_en`, `actualizado_en`) VALUES
	(1, 'admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Administrador Global', 'https://res.cloudinary.com/dbgigfmse/image/upload/v1778935691/startraining/admins/admin_1_1778935693.png', NULL, NULL, '2026-05-07 11:16:23', '2026-05-16 12:48:18');

-- Volcando estructura para tabla prueba.carreras
CREATE TABLE IF NOT EXISTS `carreras` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `creado_por` varchar(100) DEFAULT NULL,
  `actualizado_por` varchar(100) DEFAULT NULL,
  `creado_en` timestamp NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla prueba.carreras: ~13 rows (aproximadamente)
INSERT INTO `carreras` (`id`, `nombre`, `creado_por`, `actualizado_por`, `creado_en`, `actualizado_en`) VALUES
	(1, 'Ingeniería de Sistemas', NULL, NULL, '2026-05-07 11:16:22', '2026-05-07 11:16:22'),
	(2, 'Ingeniería Industrial', NULL, NULL, '2026-05-07 11:16:22', '2026-05-07 11:16:22'),
	(3, 'Ingeniería Civil', NULL, NULL, '2026-05-07 11:16:22', '2026-05-07 11:16:22'),
	(4, 'Ingeniería de Minas', NULL, NULL, '2026-05-07 11:16:22', '2026-05-07 11:16:22'),
	(5, 'Arquitectura y Urbanismo', NULL, NULL, '2026-05-07 11:16:22', '2026-05-07 11:16:22'),
	(6, 'Administración de Empresa', NULL, NULL, '2026-05-07 11:16:22', '2026-05-16 12:53:13'),
	(7, 'Marketing Digital', NULL, NULL, '2026-05-07 11:16:22', '2026-05-07 11:16:22'),
	(8, 'Contabilidad y Finanzas', NULL, NULL, '2026-05-07 11:16:22', '2026-05-07 11:16:22'),
	(9, 'Derecho Corporativo', NULL, NULL, '2026-05-07 11:16:22', '2026-05-07 11:16:22'),
	(10, 'Psicología Organizacional', NULL, NULL, '2026-05-07 11:16:22', '2026-05-07 11:16:22'),
	(11, 'Ciencias de la Comunicación', NULL, NULL, '2026-05-07 11:16:22', '2026-05-07 11:16:22'),
	(12, 'Economía y Negocios', NULL, NULL, '2026-05-07 11:16:22', '2026-05-07 11:16:22'),
	(14, 'enfermeria', NULL, NULL, '2026-05-10 16:39:55', '2026-05-10 16:39:55');

-- Volcando estructura para tabla prueba.configuracion
CREATE TABLE IF NOT EXISTS `configuracion` (
  `clave` varchar(50) NOT NULL,
  `valor` text DEFAULT NULL,
  `creado_por` varchar(100) DEFAULT NULL,
  `actualizado_por` varchar(100) DEFAULT NULL,
  `creado_en` timestamp NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`clave`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla prueba.configuracion: ~13 rows (aproximadamente)
INSERT INTO `configuracion` (`clave`, `valor`, `creado_por`, `actualizado_por`, `creado_en`, `actualizado_en`) VALUES
	('email_contacto', 'startraining44@gmail.com', NULL, NULL, '2026-05-07 11:16:22', '2026-05-16 12:59:55'),
	('facebook_url', '#', NULL, NULL, '2026-05-07 11:16:22', '2026-05-07 11:16:22'),
	('footer_descripcion', 'Plataforma líder en reclutamiento de talento profesional.', NULL, NULL, '2026-05-07 11:16:22', '2026-05-07 11:16:22'),
	('instagram_url', '#', NULL, NULL, '2026-05-07 11:16:22', '2026-05-07 11:16:22'),
	('linkedin_url', '#', NULL, NULL, '2026-05-07 11:16:22', '2026-05-07 11:16:22'),
	('logo_sitio', 'https://res.cloudinary.com/dbgigfmse/image/upload/v1778935795/startraining/branding/main_logo_1778935799.jpg', NULL, NULL, '2026-05-07 11:16:22', '2026-05-16 12:50:01'),
	('mantenimiento_msg', 'Estamos mejorando la experiencia de STARTRAINING.', NULL, NULL, '2026-05-10 16:40:10', '2026-05-16 12:57:07'),
	('mision_sitio', 'Nuestra misión es transformar y modernizar la conexión entre el talento emergente y las empresas líderes, proporcionando una plataforma centralizada, ágil y totalmente transparente. Nos dedicamos a democratizar las oportunidades laborales y optimizar los procesos de selección mediante herramientas tecnológicas intuitivas, garantizando que cada candidato encuentre el entorno ideal para su desarrollo y que cada organización descubra a los profesionales comprometidos que impulsarán su crecimiento futuro.', NULL, NULL, '2026-05-10 16:40:10', '2026-05-16 12:55:49'),
	('modo_mantenimiento', 'off', NULL, NULL, '2026-05-07 11:16:22', '2026-05-07 11:16:22'),
	('nombre_sitio', 'StarTraining', NULL, NULL, '2026-05-07 11:16:22', '2026-05-10 16:40:10'),
	('telefono_contacto', '+51 987 654 320', NULL, NULL, '2026-05-07 11:16:22', '2026-05-16 12:59:55'),
	('terminos_condiciones', 'Al crear una cuenta y acceder a los servicios de la plataforma StarTraining, la Empresa usuaria (en adelante, \'la Empresa\') acepta quedar legalmente vinculada por los presentes Términos y Condiciones. La Empresa declara bajo juramento que toda la información y documentación proporcionada durante el proceso de registro (incluyendo número de RUC, identidad del representante legal, documentos adjuntos y datos de contacto) es completamente veraz, exacta, lícita y se encuentra vigente. Asimismo, la Empresa autoriza de manera expresa a StarTraining a realizar las verificaciones pertinentes de dicha información mediante consultas a bases de datos de entidades públicas (como SUNAT).\r\n\r\n1. Uso Exclusivo y Propósito de la Plataforma El acceso y uso de las funcionalidades de este sistema están estrictamente limitados a la publicación de convocatorias laborales o de prácticas legítimas, y a la evaluación integral de candidatos con el fin exclusivo de ejecutar procesos de reclutamiento y eventual contratación.\r\n\r\n2. Confidencialidad y Protección de Datos Personales Queda terminantemente prohibido, bajo sanción legal y expulsión inmediata de la plataforma, la extracción, venta, transferencia o distribución de los datos personales, currículums vitae e información de contacto de los postulantes para fines comerciales de terceros, campañas de marketing, envío de spam o cualquier otra actividad ajena al proceso de selección directo. La Empresa asume la responsabilidad total y legal de proteger la privacidad y salvaguardar los perfiles que recibe.\r\n\r\n3. Obligaciones y Transparencia en la Publicación Las convocatorias publicadas deberán reflejar oportunidades de trabajo reales y transparentes. Se prohíbe estrictamente la publicación de ofertas engañosas, esquemas de trabajo piramidal, vacantes que exijan pagos, depósitos o compras previas por parte del candidato, así como cualquier publicación que contenga sesgos o fomente la discriminación por motivos de raza, género, religión, nacionalidad u orientación sexual.\r\n\r\n4. Sanciones y Cancelación de la Cuenta StarTraining se reserva el derecho exclusivo de monitorear, auditar, suspender temporalmente o bloquear de manera permanente e inapelable el acceso a cualquier cuenta empresarial que proporcione información fraudulenta, incumpla las normativas detalladas en este acuerdo, reciba quejas justificadas por parte de los postulantes, o realice prácticas que atenten contra la ética y seguridad laboral.\r\n\r\nAl marcar esta casilla y completar el proceso de registro, el usuario declara ser el representante legal autorizado para obligar a la Empresa a cumplir con estas normativas, aceptando incondicionalmente nuestras políticas de uso y liberando a StarTraining de cualquier responsabilidad derivada del uso indebido de los datos por parte de la Empresa.', NULL, NULL, '2026-05-07 11:16:22', '2026-05-16 12:55:49'),
	('twitter_url', '#', NULL, NULL, '2026-05-07 11:16:22', '2026-05-07 11:16:22');

-- Volcando estructura para tabla prueba.empresas
CREATE TABLE IF NOT EXISTS `empresas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_comercial` varchar(150) NOT NULL,
  `ruc` varchar(11) NOT NULL,
  `sector` varchar(100) DEFAULT NULL,
  `correo_contacto` varchar(150) NOT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `direccion` text DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `foto_perfil` text DEFAULT NULL,
  `ficha_ruc` text DEFAULT NULL,
  `dni_frente` text DEFAULT NULL,
  `dni_reverso` text DEFAULT NULL,
  `foto_selfie` text DEFAULT NULL,
  `estado` varchar(20) DEFAULT 'pendiente',
  `es_top` tinyint(1) DEFAULT 0,
  `creado_por` varchar(100) DEFAULT NULL,
  `actualizado_por` varchar(100) DEFAULT NULL,
  `creado_en` timestamp NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ruc` (`ruc`),
  UNIQUE KEY `correo_contacto` (`correo_contacto`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla prueba.empresas: ~1 rows (aproximadamente)
INSERT INTO `empresas` (`id`, `nombre_comercial`, `ruc`, `sector`, `correo_contacto`, `telefono`, `direccion`, `password_hash`, `foto_perfil`, `ficha_ruc`, `dni_frente`, `dni_reverso`, `foto_selfie`, `estado`, `es_top`, `creado_por`, `actualizado_por`, `creado_en`, `actualizado_en`) VALUES
	(5, 'COOPERATIVA DE AHORRO Y CRÉDITO "SAN CRISTÓBAL DE HUAMANGA" LTDA.', '20129175975', 'GENERAL', 'copa@gmail.com', '912345678', 'NRO. 33  PORTAL UNION, AYACUCHO - HUAMANGA - AYACUCHO', '$2y$10$MwkrjU/H4ycFhgd8VD6R6.f9D8IeuBtFq3G2Fs7dEnUEosNkSiHz2', 'https://res.cloudinary.com/dbgigfmse/image/upload/v1778444663/startraining/logos/logo_20129175975.jpg', 'https://res.cloudinary.com/dbgigfmse/image/upload/v1778444665/startraining/documentos/ficha_20129175975.pdf', 'https://res.cloudinary.com/dbgigfmse/image/upload/v1778444667/startraining/documentos/dni_f_20129175975.jpg', 'https://res.cloudinary.com/dbgigfmse/image/upload/v1778444668/startraining/documentos/dni_r_20129175975.png', 'https://res.cloudinary.com/dbgigfmse/image/upload/v1778444670/startraining/biometria/selfie_20129175975.jpg', 'activo', 0, NULL, NULL, '2026-05-10 20:24:31', '2026-05-10 20:25:24'),
	(6, 'OFICINA NACIONAL DE PROCESOS ELECTORALES', '20291973851', 'GENERAL', 'onpe@gmail.com', '987655654', 'JR. WASHINGTON NRO. 1894, LIMA - LIMA - LIMA', '$2y$10$.ZdoUUdhkBJvYexfJASvTelVXf7Um8aWPHYR6B0NUQKF9pZZon1g.', 'https://res.cloudinary.com/dbgigfmse/image/upload/v1778943678/startraining/logos/logo_20291973851.jpg', 'https://res.cloudinary.com/dbgigfmse/image/upload/v1778943679/startraining/documentos/ficha_20291973851.pdf', 'https://res.cloudinary.com/dbgigfmse/image/upload/v1778943681/startraining/documentos/dni_f_20291973851.jpg', 'https://res.cloudinary.com/dbgigfmse/image/upload/v1778943682/startraining/documentos/dni_r_20291973851.png', 'https://res.cloudinary.com/dbgigfmse/image/upload/v1778943683/startraining/biometria/selfie_20291973851.png', 'pendiente', 0, NULL, NULL, '2026-05-16 15:01:29', '2026-05-16 15:01:29');

-- Volcando estructura para tabla prueba.postulaciones
CREATE TABLE IF NOT EXISTS `postulaciones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vacante_id` int(11) NOT NULL,
  `dni` varchar(15) NOT NULL,
  `nombre_completo` varchar(200) NOT NULL,
  `correo_estudiante` varchar(150) NOT NULL,
  `celular` varchar(20) NOT NULL,
  `url_cv_pdf` text DEFAULT NULL,
  `match_porcentaje` decimal(5,2) DEFAULT 0.00,
  `ia_analisis_descripcion` text DEFAULT NULL,
  `estado_postulacion` varchar(20) DEFAULT 'en_espera',
  `notificacion_leida` tinyint(1) DEFAULT 0,
  `creado_por` varchar(100) DEFAULT NULL,
  `actualizado_por` varchar(100) DEFAULT NULL,
  `fecha_postulacion` timestamp NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_postulacion_dni` (`vacante_id`,`dni`),
  CONSTRAINT `fk_vacante` FOREIGN KEY (`vacante_id`) REFERENCES `vacantes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando estructura para tabla prueba.vacantes
CREATE TABLE IF NOT EXISTS `vacantes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `empresa_id` int(11) NOT NULL,
  `carrera_id` int(11) DEFAULT NULL,
  `titulo_puesto` varchar(150) NOT NULL,
  `descripcion_puesto` text NOT NULL,
  `requisitos_raw` text NOT NULL,
  `modalidad` varchar(50) DEFAULT NULL,
  `ubicacion` varchar(100) DEFAULT NULL,
  `fecha_limite` date DEFAULT NULL,
  `estado` varchar(20) DEFAULT 'abierta',
  `creado_por` varchar(100) DEFAULT NULL,
  `actualizado_por` varchar(100) DEFAULT NULL,
  `creado_en` timestamp NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_empresa` (`empresa_id`),
  KEY `fk_carrera` (`carrera_id`),
  CONSTRAINT `fk_carrera` FOREIGN KEY (`carrera_id`) REFERENCES `carreras` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_empresa` FOREIGN KEY (`empresa_id`) REFERENCES `empresas` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
